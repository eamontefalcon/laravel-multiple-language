	

	<!-- Modal -->
	<div id="AreaModal" class="modal fade" role="dialog">
	  <div class="modal-dialog">

	    <!-- Modal content-->
	    <div class="modal-content">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal">&times;</button>
	        <h4 class="modal-title">Area</h4>
	      </div>
	      <div class="modal-body">

	      		<div style="margin:10px;">   			
		      		<!-- Form -->
			        <form class="form-horizontal" id="form-area" method="POST" action="{{route('areas.store')}}">
			          @csrf

			          <input type="hidden" name="_method" id="form-method" value="POST">

					  <div style="margin:auto;text-align:center;">
					  	<h4>Translation Lists</h4>
					  	<p>(Area Name)</p>
					  </div>

					  <div class="form-group hidden">
					    <label for="area-id">Area ID:</label>
					    <input type="text" class="form-control" id="area-id" name="area_id_update">
					  </div>

					  <!-- Language temporarily hardcoded-->
					  <!-- To Do  (Make it Dynamic based on language current supported)-->

					  <div class="form-group">
					    <label for="en">English(en):</label>
					    <input type="text" class="form-control" id="en" name="en">
					  </div>
					  <div class="form-group">
					    <label for="ja">Japanese(ja):</label>
					    <input type="text" class="form-control" id="ja" name="ja">
					  </div>
					  <div class="form-group">
					    <label for="ms">Malay(ms):</label>
					    <input type="text" class="form-control" id="ms" name="ms">
					  </div>

					  <button type="submit" class="btn btn-default">Submit</button>
					</form> 
				</div>


	      </div>
	      <div class="modal-footer">
	        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
	      </div>
	    </div>

	  </div>
	</div>



	<script type="text/javascript">
		function updateTranslate(languages, areaID)
		{

			$('#form-area').attr('action', '/areas/'+areaID);
			$('#form-method').val('put');

			for (lang in languages) {

			    if(languages[lang]['locale'] == 'en'){
			   		$('#en').val(languages[lang]['name']);
				}

			    if(languages[lang]['locale'] == 'ja'){
			   		$('#ja').val(languages[lang]['name']);
				}

				if(languages[lang]['locale'] == 'ms'){
			   	    $('#ms').val(languages[lang]['name']);
				}
			}
		}


	</script>
