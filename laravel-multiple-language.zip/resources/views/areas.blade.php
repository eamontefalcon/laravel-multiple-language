<!DOCTYPE html>
<html>
<head>
	<title>Areas</title>

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

</head>
<body class="container">
	<!-- Current Language -->
	<h2>Current Language is {{$locale}}</h2>

	<!--  Change the current language-->
	<div class="dropdown">
	  <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">
	  	List of Available Language
	  <span class="caret"></span></button>
	  <ul class="dropdown-menu">
	  	@foreach($languages as $key => $language)
		    @if($language == $locale)
		    	<li class="active"><a href="#">{{$language}}</a></li>
		    @else
		    	<li><a href="/locale/{{$key}}">{{$language}}</a></li>
		    @endif
	    @endforeach
	  </ul>
	</div>
	<!--  -->

	<!-- All Areas View-->
	<h2>List of Areas</h2>

	<!-- Add Area -->
	<button type="button" class="btn btn-info btn-lg" 
	        data-toggle="modal" data-target="#AreaModal">Add New Area
	</button>

	<div style="margin-top:10px;margin-bottom:10px;">
		@if(Session::has("status"))
		<div class="alert alert-success" role="alert">
		  {{Session::get("status")}}
		</div>
	@endif	

	</div>


	<table class="table table-bordered">
	    <thead>
	      <tr>

	      	<!--This will be change whenever you change your language-->
	        <th>Name ({{$locale}})</th>

	        <th>Translations</th>
	        <th>Update Translation</th>
	      </tr>
	    </thead>
	    <tbody>
	    	@foreach($areas as $area)	
	    	  <tr>
	    	  	<td>{{$area->name}}</td>
				<td> 
				  @foreach($area->translations as $translate)
				  	<p>{{$translate->locale}} : "{{$translate->name}}"</p>
				  @endforeach

				</td>
				<td>
				<button type="button" class="btn btn-primary" 
				        data-toggle="modal" data-target="#AreaModal" 
				        onclick="updateTranslate({{$area->translations}}, {{$area->id}})">Update Translation
				</button>
				</td>
	    	  </tr>
	    	@endforeach
	    </tbody>
	</table>
	<!--  -->



	@include('includes.area_modal_store_update')



</body>
</html>