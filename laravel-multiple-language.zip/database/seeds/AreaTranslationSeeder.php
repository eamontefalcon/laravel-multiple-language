<?php

use App\Models\Area;
use App\Models\AreaTranslation;
use Illuminate\Database\Seeder;

class AreaTranslationSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        
      	$area = Area::create([
    		'is_active' => 1
    	]);

    	$area2 = Area::create([
    		'is_active' => 1
    	]);
        
        
    	AreaTranslation::insert([

    		//area 1 data
    		[
    			'area_id' => $area->id, 
    			'name' => 'lobby',
    			'locale' => 'en'
    	    ],
    		[
    			'area_id' => $area->id, 
    			'name' => 'ロビー',
    			'locale' => 'ja'
    	    ],
    	    [
    			'area_id' => $area->id, 
    			'name' => 'lobi',
    			'locale' => 'ms'
    	    ],

    	    //area 2 data

    		[
    			'area_id' => $area2->id, 
    			'name' => 'food court',
    			'locale' => 'en'
    	    ],
    		[
    			'area_id' => $area2->id, 
    			'name' => 'フードコート',
    			'locale' => 'ja'
    	    ],
    	    [
    			'area_id' => $area2->id, 
    			'name' => 'medan selera',
    			'locale' => 'ms'
    	    ],

		]);

    }
}
