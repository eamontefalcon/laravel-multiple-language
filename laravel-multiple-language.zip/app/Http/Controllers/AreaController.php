<?php

namespace App\Http\Controllers;

use App\Models\Area;
use App\Models\AreaTranslation;
use Illuminate\Http\Request;

class AreaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //get all areas
        $areas = Area::all();

        //get current language
        $locale =  \App::getLocale();

        //this language is for demo purposes only
        //you can make languages table to database to be more dynamic
        $languages = [ 'en' => 'English',
                       'ja' => 'Japanese', 
                       'ms' => 'Malay'
                     ];
        //get the value in languages
        //to be more readable in user side           
        $locale = $languages[$locale];

        //pass all the values to view
        return view('areas', compact('areas','locale' ,'languages'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //validation
        // To Do return error in view
        $request->validate([
            'en' => 'required',
            'ja' => 'required',
            'ms' => 'required'
        ]);

        //To Do  clean the code
    
        $en = $request->en;
        $ja = $request->ja;
        $ms = $request->ms;

        //make area data
        $area = Area::create([
            'is_active' => 1,
        ]);

        $enTrans = AreaTranslation::create([
            'area_id' => $area->id,
            'name'    => $request->en,
            'locale'  => 'en'
        ]);

        $jaTrans = AreaTranslation::create([
            'area_id' => $area->id,
            'name'    => $request->ja,
            'locale'  => 'ja'
        ]);

        $msTrans = AreaTranslation::create([
            'area_id' => $area->id,
            'name'    => $request->ms,
            'locale'  => 'ms'
        ]);

        session()->flash('status', 'New area has been stored');

        return redirect()->back();


    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        //To DO  - Code Clean up

        //validation
        // To Do return error in view
        $request->validate([
            'en' => 'required',
            'ja' => 'required',
            'ms' => 'required'
        ]);



        $areaTranslation = AreaTranslation::where('area_id', $id)
                                           ->where('locale', 'en')
                                           ->first();
        $areaTranslation->name = $request->en;
        $areaTranslation->save();

        $areaTranslation = AreaTranslation::where('area_id', $id)
                                           ->where('locale', 'ja')
                                           ->first();
        $areaTranslation->name = $request->ja;
        $areaTranslation->save();

        $areaTranslation = AreaTranslation::where('area_id', $id)
                                           ->where('locale', 'ms')
                                           ->first();
        $areaTranslation->name = $request->ms;
        $areaTranslation->save();

        session()->flash('status', 'Translation has been updated');
        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
